# 🎯 Tebak Kata - Multiplayer Game

Game Tebak Kata (Wordle Indonesia) dengan 4 mode:
- **Single Player** - Main sendirian
- **Multiplayer 1v1** - Pilih kata untuk lawan, tebak kata dari lawan
- **Battle Royale** - Kata dari sistem, unlimited players, cepet-cepetan!
- **TikTok Live** - Komentar TikTok live jadi tebakan otomatis

## 🚀 Cara Deploy ke Railway

### 1. Siapkan File
Extract zip ini, struktur folder harus seperti ini:
```
tebak_kata_game/
├── public/
│   └── index.html
├── server.js
└── package.json
```

### 2. Deploy ke Railway
1. Buka https://railway.app
2. Login dengan GitHub
3. Klik **New Project** → **Deploy from GitHub repo**
4. Pilih repo atau upload folder ini
5. Railway otomatis detect Node.js dan run `npm start`
6. Tunggu deployment selesai (2-3 menit)

### 3. Akses Game
Setelah deploy berhasil:
1. Railway kasih URL seperti: `https://tebak-kata-production.up.railway.app`
2. Buka URL itu di browser HP/laptop
3. **Langsung main!** Tidak perlu setting apapun

## 💡 Tips

**URL otomatis terdeteksi!** Client otomatis konek ke WebSocket di host yang sama. Jadi:
- Buka via Railway → konek ke `wss://tebak-kata-production.up.railway.app`
- Buka via localhost → konek ke `ws://localhost:8080`

**Kalau mau hardcode URL:**
Edit `public/index.html` baris 442-450, ganti jadi:
```js
const SERVER_URL = 'wss://URL-RAILWAY-KAMU.up.railway.app';
```

## 🆓 Alternatif Hosting Gratis

Railway sekarang butuh kartu kredit. Alternatif gratis:

### Render.com (Recommended)
1. Buka https://render.com
2. New → Web Service
3. Connect repository
4. Build: `npm install`
5. Start: `npm start`
6. **FREE unlimited**

### Glitch.com
1. Buka https://glitch.com
2. New Project → Import from GitHub
3. Langsung jalan, auto-restart
4. **FREE unlimited**

## 🎮 Cara Main

### Mode Multiplayer 1v1
1. Player 1: Klik **Buat Room** → dapat kode
2. Player 2: Klik **Join Room** → masukkan kode
3. **Keduanya pilih kata rahasia** untuk ditebak lawan
4. Game mulai otomatis setelah keduanya submit
5. Cepet-cepetan tebak!

### Mode Battle Royale
1. Player 1: Klik **Buat Room** → dapat kode
2. Player 2, 3, 4, dst: **Join Room** pakai kode yang sama
3. **Tidak ada batas pemain!**
4. Host klik **Mulai Game**
5. Sistem pilih kata acak, semua dapat kata yang **sama**
6. Siapa duluan tebak benar = 🥇 Juara!

## 📝 Troubleshooting

**"Upgrade Required" / Server tidak connect:**
- Cek Railway dashboard: Deployments → lihat log error
- Pastikan `package.json` ada dependency `ws`
- Free tier Railway mungkin sudah habis → pakai Render.com

**Game tidak muncul:**
- Pastikan folder `public/` ada dan berisi `index.html`
- Cek console browser (F12) → lihat error

**WebSocket gagal connect:**
- Pastikan Railway/hosting support WebSocket
- Cek URL di `public/index.html` sudah benar

## 🛠️ Development Local

```bash
# Install dependencies
npm install

# Jalankan server
npm start

# Buka browser
http://localhost:8080
```

Server jalan di port 8080, buka `http://localhost:8080` untuk main.

## 📄 License
MIT - Bebas dipakai, dimodif, dideploy sesuka hati!
