const { WebSocketServer, WebSocket } = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 8080;

// ── HTTP Server untuk serve index.html ──
const server = http.createServer((req, res) => {
  let filePath = req.url === '/' ? '/index.html' : req.url;
  filePath = path.join(__dirname, 'public', filePath);
  
  const ext = path.extname(filePath);
  const contentType = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'text/javascript',
    '.json': 'application/json'
  }[ext] || 'text/plain';

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('404 Not Found');
      return;
    }
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
});

// ── WebSocket Server ──
const wss = new WebSocketServer({ server });

const rooms = {};     // mode 1v1
const brRooms = {};   // mode battle royale

// Daftar kata untuk Battle Royale (sistem yang pilih)
const BR_WORDS = [
  "BAKAT","BALAP","BALIK","BATIK","BAYAR","BEKAL","BELAH","BELOK","BENAR","BESAR",
  "BIJAK","BIKIN","BINAR","BOLEH","BOTAK","BULAN","BURAM","CALON","CEPAT","CERAH",
  "CINTA","DAMAI","DAPAT","DARAH","DEKAT","DALAM","DEBUT","DETIK","DEWAN","DINAS",
  "FAJAR","FAKTA","FOKUS","GANAS","GERAK","GIGIH","GITAR","GULAT","HABIS","HADIR",
  "HAFAL","HALUS","HARAP","HEMAT","HIDUP","HIJAU","HITAM","HURUF","JALUR","JARAK",
  "JELAS","KABAR","KABUR","KAGET","KALAH","KAMUS","KAPAL","KASUS","KERAS","KETUA",
  "KIRIM","KOTOR","KUASA","LAPAR","LAPOR","LARIS","LEBIH","LEMAH","LIHAT","LISAN",
  "LOGAM","LUGAS","MABUK","MAHAL","MAHIR","MAKIN","MAKAN","MALAS","MAMPU","MARAK",
  "MAWAR","MEKAR","MERAH","MILIK","MINTA","MODAL","MUDAH","MULAI","MULIA","MURNI",
  "NAKAL","NEKAT","NYATA","ORANG","PADAT","PAHAM","PAHIT","PAKAI","PANAS","PANEN",
  "PASAR","PECAH","PEDAS","PEKAN","POKOK","PULIH","PUTIH","RAMAI","RAMAH","RAPUH",
  "RESMI","RIMBA","RISET","RUSAK","SABAR","SALDO","SALAH","SAMAR","SARAF","SARAT",
  "SEHAT","SIAGA","SIGAP","SOSOK","SUARA","SUBUR","SUSAH","TANAM","TANDA","TANPA",
  "TEPAT","TEGAS","TENTU","TERUS","TIANG","TIPIS","TUBUH","TUGAS","TURUN","USAHA",
  "UTAMA","WAJAH","BRAIN","BRAVE","BREAD","BREAK","BRING","BUILD","CARRY","CATCH",
  "CHAIN","CHARM","CHASE","CHECK","CLEAN","CLEAR","CLOCK","CLOSE","CLOUD","COUNT",
  "CRACK","CRAFT","CRASH","CRAZY","CRIME","CROSS","CROWD","CROWN","DAILY","DANCE",
  "DEATH","DREAM","DRINK","DRIVE","EAGLE","EARTH","ENJOY","EQUAL","EXTRA","FAITH",
  "FEAST","FIGHT","FINAL","FIRST","FLAME","FLASH","FLOAT","FLOOR","FORCE","FRAME",
  "FRESH","GHOST","GRACE","GRAND","GRAPE","GRASS","GREAT","GREEN","GROUP","GUARD",
  "HEART","HEAVY","HONEY","HONOR","HORSE","HOTEL","HOUSE","HUMAN","IMAGE","JOINT",
  "JUDGE","KARMA","KNIFE","KNOCK","LARGE","LAUGH","LAYER","LEARN","LEGAL","LEVEL",
  "LIGHT","MAGIC","MAJOR","MARCH","MATCH","MEDIA","METAL","MIGHT","MONEY","MONTH",
  "MORAL","MOVIE","MUSIC","NIGHT","NINJA","NORTH","NOVEL","OCEAN","ORDER","PARTY",
  "PEACE","PHONE","PHOTO","PILOT","PIZZA","PLACE","PLANT","PLATE","POINT","POWER",
  "PRICE","PRIDE","PRIME","PRINT","PRIZE","PROOF","QUEEN","QUEST","QUICK","QUIET",
  "RADAR","RADIO","RAISE","RANGE","RAPID","REACH","READY","RELAX","REPLY","RIGHT",
  "RIVAL","RIVER","ROBOT","ROUND","ROUTE","ROYAL","SAINT","SALAD","SAUCE","SCALE",
  "SCENE","SCORE","SENSE","SHAKE","SHAPE","SHARE","SHARK","SHARP","SHIFT","SHINE",
  "SHOCK","SIGHT","SINCE","SKILL","SLEEP","SLIDE","SMILE","SMOKE","SNAKE","SOLID",
  "SOLVE","SOUTH","SPACE","SPARK","SPEAK","SPEED","SPEND","SPLIT","SPORT","STAGE",
  "STAND","START","STATE","STEEL","STICK","STILL","STOCK","STONE","STORE","STORM",
  "STORY","STYLE","SUGAR","SUPER","SWEET","SWIFT","SWORD","TASTE","TEACH","THEME",
  "THICK","THINK","THREE","TIGHT","TIMER","TITLE","TODAY","TOPIC","TOTAL","TOUGH",
  "TOWER","TOXIC","TRACK","TRADE","TRAIN","TRAIL","TRUST","TRUTH","TWIST","UNDER",
  "UNION","UNTIL","UPSET","USAGE","VALID","VALUE","VIDEO","VIRAL","VITAL","VIVID",
  "VOICE","WASTE","WATCH","WATER","WHEEL","WHITE","WHOLE","WOMAN","WORLD","WORRY",
  "WORTH","WRITE","YOUNG","YOUTH","ZEBRA"
];

function brRandomWord() { return BR_WORDS[Math.floor(Math.random() * BR_WORDS.length)]; }
function genId() { return Math.random().toString(36).substr(2, 8); }

function send(ws, data) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}
function broadcast(room, data, exceptWs = null) {
  for (const p of Object.values(room.players)) {
    if (p.ws !== exceptWs) send(p.ws, data);
  }
}

function log(...args) { console.log(new Date().toISOString(), ...args); }

wss.on('connection', (ws) => {
  ws.roomCode = null;
  ws.role = null;
  ws.playerId = null;
  ws.mode = null; // '1v1' | 'br'

  ws.on('message', (raw) => {
    let data;
    try { data = JSON.parse(raw); } catch { return; }

    // ══════════════════════════════════════
    // MODE 1v1 (existing logic)
    // ══════════════════════════════════════
    if (data.type === 'create') {
      const code = Math.random().toString(36).substr(2, 6).toUpperCase();
      rooms[code] = { host: ws, guest: null, hostName: data.name || 'Host', guestName: '', hostWord: null, guestWord: null, state: 'waiting' };
      ws.roomCode = code; ws.role = 'host'; ws.mode = '1v1';
      send(ws, { type: 'created', code });
      log(`[1v1] Room ${code} dibuat oleh ${data.name}`);
    }
    else if (data.type === 'join') {
      const code = data.code?.toUpperCase();
      const room = rooms[code];
      if (!room) { send(ws, { type: 'error', msg: 'Room tidak ditemukan' }); return; }
      if (room.guest && room.guest.readyState === WebSocket.OPEN) { send(ws, { type: 'error', msg: 'Room sudah penuh' }); return; }
      room.guest = ws; room.guestName = data.name || 'Guest';
      ws.roomCode = code; ws.role = 'guest'; ws.mode = '1v1'; room.state = 'choosing';
      send(ws, { type: 'joined', code, opponentName: room.hostName });
      send(room.host, { type: 'opponent_joined', opponentName: room.guestName });
      log(`[1v1] ${data.name} join room ${code}`);
    }
    else if (data.type === 'set_word') {
      const room = rooms[ws.roomCode]; if (!room) return;
      const word = data.word?.toUpperCase(); if (!word || word.length !== 5) return;
      if (ws.role === 'host') room.hostWord = word; else room.guestWord = word;
      const target = ws.role === 'host' ? room.guest : room.host;
      send(target, { type: 'opponent_ready' }); send(ws, { type: 'word_set_ok' });
      if (room.hostWord && room.guestWord) {
        room.state = 'playing';
        send(room.host,  { type: 'game_start', word: room.guestWord, opponentName: room.guestName });
        send(room.guest, { type: 'game_start', word: room.hostWord,  opponentName: room.hostName });
      }
    }
    else if (data.type === 'relay') {
      const room = rooms[ws.roomCode]; if (!room) return;
      const target = ws.role === 'host' ? room.guest : room.host;
      send(target, { type: 'relay', payload: data.payload });
    }
    else if (data.type === 'play_again') {
      const room = rooms[ws.roomCode]; if (!room) return;
      if (ws.role === 'host') room.hostWord = null; else room.guestWord = null;
      room.state = 'choosing';
      const target = ws.role === 'host' ? room.guest : room.host;
      send(target, { type: 'opponent_play_again' }); send(ws, { type: 'play_again_ok' });
    }
    else if (data.type === 'leave_room') {
      const code = ws.roomCode; if (!code || !rooms[code]) return;
      const room = rooms[code];
      const target = ws.role === 'host' ? room.guest : room.host;
      send(target, { type: 'opponent_left' });
      delete rooms[code]; ws.roomCode = null; ws.role = null;
    }
    else if (data.type === 'ping') { send(ws, { type: 'pong' }); }

    // ══════════════════════════════════════
    // MODE BATTLE ROYALE
    // ══════════════════════════════════════
    else if (data.type === 'br_create') {
      const code = Math.random().toString(36).substr(2, 6).toUpperCase();
      const pid = genId();
      brRooms[code] = {
        players: { [pid]: { ws, name: data.name || 'Host', id: pid, isHost: true } },
        hostId: pid,
        state: 'lobby',  // lobby | playing
        word: null,
        winRank: 0
      };
      ws.roomCode = code; ws.playerId = pid; ws.mode = 'br';
      const playersMap = brGetPlayersMap(brRooms[code]);
      send(ws, { type: 'br_created', code, myId: pid, players: playersMap });
      log(`[BR] Room ${code} dibuat oleh ${data.name}`);
    }
    else if (data.type === 'br_join') {
      const code = data.code?.toUpperCase();
      const room = brRooms[code];
      if (!room) { send(ws, { type: 'br_error', msg: 'Room tidak ditemukan' }); return; }
      if (room.state === 'playing') { send(ws, { type: 'br_error', msg: 'Game sudah berjalan' }); return; }
      const pid = genId();
      room.players[pid] = { ws, name: data.name || 'Pemain', id: pid, isHost: false };
      ws.roomCode = code; ws.playerId = pid; ws.mode = 'br';
      const playersMap = brGetPlayersMap(room);
      send(ws, { type: 'br_joined', code, myId: pid, players: playersMap });
      // Beritahu semua yang sudah ada
      broadcast(room, { type: 'br_player_update', action: 'join', name: data.name || 'Pemain', players: playersMap }, ws);
      log(`[BR] ${data.name} join room ${code}, total: ${Object.keys(room.players).length}`);
    }
    else if (data.type === 'br_start') {
      const room = brRooms[ws.roomCode];
      if (!room || room.players[ws.playerId]?.isHost === false) return;
      if (Object.keys(room.players).length < 2) { send(ws, { type: 'br_error', msg: 'Minimal 2 pemain!' }); return; }
      room.state = 'playing';
      room.word = brRandomWord();
      room.winRank = 0;
      // Reset skor semua pemain
      Object.values(room.players).forEach(p => { p.won = false; p.lost = false; p.tries = 0; p.done = false; });
      const playersMap = brGetPlayersMap(room);
      broadcast(room, { type: 'br_game_start', word: room.word, players: playersMap });
      log(`[BR] Room ${ws.roomCode} game start, kata: ${room.word}, pemain: ${Object.keys(room.players).length}`);
    }
    else if (data.type === 'br_result') {
      const room = brRooms[ws.roomCode];
      if (!room || room.state !== 'playing') return;
      const p = room.players[ws.playerId];
      if (!p || p.done) return;
      p.done = true;
      p.won = data.won;
      p.lost = !data.won;
      p.tries = data.tries;
      if (data.won) room.winRank++;
      const rank = data.won ? room.winRank : 0;
      // Broadcast hasil pemain ini ke semua
      broadcast(room, { type: 'br_player_result', playerId: ws.playerId, won: data.won, tries: data.tries, rank });
      log(`[BR] Room ${ws.roomCode}: ${p.name} ${data.won ? 'MENANG' : 'kalah'} (${data.tries} percobaan)`);
      // Cek apakah semua sudah selesai
      const all = Object.values(room.players).every(pl => pl.done);
      if (all) {
        room.state = 'finished';
        broadcast(room, { type: 'br_game_over', word: room.word });
        log(`[BR] Room ${ws.roomCode} game over`);
      }
    }
    else if (data.type === 'br_play_again') {
      const room = brRooms[ws.roomCode];
      if (!room) return;
      // Hanya host yang bisa trigger reset, atau semua sudah kirim play_again
      // Simpel: siapapun kirim, langsung reset (host decide)
      if (!room.players[ws.playerId]?.isHost) {
        // Non-host minta main lagi → broadcast ke host
        send(room.players[room.hostId]?.ws, { type: 'br_play_again_request', name: room.players[ws.playerId]?.name });
        return;
      }
      // Host mereset
      room.state = 'lobby';
      room.word = null;
      room.winRank = 0;
      Object.values(room.players).forEach(p => { p.done = false; p.won = false; p.lost = false; p.tries = 0; });
      const playersMap = brGetPlayersMap(room);
      broadcast(room, { type: 'br_reset', players: playersMap });
    }
    else if (data.type === 'br_leave') {
      brHandleLeave(ws);
    }
  });

  ws.on('close', () => {
    if (ws.mode === 'br') {
      brHandleLeave(ws);
    } else {
      const code = ws.roomCode;
      if (!code || !rooms[code]) return;
      const room = rooms[code];
      const target = ws.role === 'host' ? room.guest : room.host;
      send(target, { type: 'opponent_left' });
      delete rooms[code];
    }
  });

  ws.on('error', () => {});
});

function brGetPlayersMap(room) {
  const map = {};
  for (const [id, p] of Object.entries(room.players)) {
    map[id] = { name: p.name, id: p.id, isHost: p.isHost };
  }
  return map;
}

function brHandleLeave(ws) {
  const code = ws.roomCode;
  if (!code || !brRooms[code]) return;
  const room = brRooms[code];
  const pid = ws.playerId;
  const name = room.players[pid]?.name || '?';
  delete room.players[pid];
  ws.roomCode = null; ws.playerId = null;
  log(`[BR] ${name} keluar room ${code}`);

  if (Object.keys(room.players).length === 0) {
    delete brRooms[code];
    log(`[BR] Room ${code} kosong, dihapus`);
    return;
  }
  // Jika host yang keluar, tunjuk host baru
  if (room.hostId === pid) {
    const newHostId = Object.keys(room.players)[0];
    room.players[newHostId].isHost = true;
    room.hostId = newHostId;
    send(room.players[newHostId].ws, { type: 'br_you_are_host' });
  }
  const playersMap = brGetPlayersMap(room);
  broadcast(room, { type: 'br_player_update', action: 'leave', name, players: playersMap });
}

server.listen(PORT, () => {
  log(`✅ Server jalan di port ${PORT}`);
  log(`🌐 Buka http://localhost:${PORT} untuk main`);
});
